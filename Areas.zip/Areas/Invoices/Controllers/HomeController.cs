﻿using Microsoft.AspNetCore.Mvc;

namespace ECommerce.Areas.Invoices.Controllers
{
    [Area("Invoices")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
