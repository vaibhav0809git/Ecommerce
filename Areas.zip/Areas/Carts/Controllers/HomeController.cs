﻿using Microsoft.AspNetCore.Mvc;

namespace ECommerce.Areas.Carts.Controllers
{
    [Area("Carts")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
