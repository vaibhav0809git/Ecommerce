﻿using Microsoft.AspNetCore.Mvc;

namespace ECommerce.Areas.Categories.Controllers
{
    [Area("Categories")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
