﻿using Microsoft.AspNetCore.Mvc;

namespace ECommerce.Areas.Products.Controllers
{
    [Area("Products")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
